# 🔥 Ember — Food Ordering Hub

A sleek, dark-themed food ordering mini-app built with React + Vite + Tailwind CSS.

## Features

### Core
- **Responsive Menu Grid** — auto-fill CSS grid of modular `FoodCard` components
- **Cart Sidebar** — fixed on desktop, sliding drawer on mobile/tablet
- **Real-time calculations** — total price and item count update instantly
- **Live item counter** — persistent badge in the header

### Innovation / Smart Features
- 🌙 **Dark / Light theme toggle** — persisted via `localStorage`
- 💾 **Persistent cart** — survives page refresh via `localStorage`
- 🔍 **Search** — fuzzy-matches name, description, category
- 🏷️ **Category filter pills** — All, Pizza, Burgers, Pasta, Salads, Desserts, Drinks
- ↕️ **Sort** — Default, Top Rated, Price ↑, Price ↓
- 🎁 **Promo codes** — EMBER10 (10%), FIRST20 (20%), STUDENT (15%)
- 🚚 **Free delivery progress bar** — unlocks at $50
- ✨ **Micro-animations** — ripple on "Add to Cart", emoji scale on hover, card lift
- 📋 **Checkout modal flow** — confirm → success with 3s auto-close
- 🌶️ Spicy / 🌿 Veg badges on cards
- ⚡ In-cart quantity counter displayed on card image

## Tech Stack

| Tool | Purpose |
|------|---------|
| React 18 | UI framework |
| Vite 5 | Build tool & dev server |
| Tailwind CSS 3 | Utility-first styling |
| Lucide React | Icon system |
| localStorage | Cart & theme persistence |

## File Structure

```
food-ordering-hub/
├── public/
│   └── images/              # Static assets placeholder
├── src/
│   ├── assets/              # Global branding (extend as needed)
│   ├── components/
│   │   ├── FoodCard.jsx     # Individual food card with quantity controls
│   │   ├── MenuGrid.jsx     # Search, filter, sort + grid layout
│   │   └── CartSidebar.jsx  # Sliding cart drawer + checkout modal
│   ├── data/
│   │   └── menuData.js      # Centralised menu items & categories
│   ├── hooks/
│   │   ├── useCart.js       # Cart state + localStorage persistence
│   │   └── useTheme.js      # Dark/light mode + localStorage persistence
│   ├── App.jsx              # Root — layout, global state wiring
│   ├── index.css            # Tailwind base + keyframe animations
│   └── main.jsx             # ReactDOM injection
├── .gitignore
├── index.html
├── package.json
├── postcss.config.js
├── tailwind.config.js
└── vite.config.js
```

## Getting Started

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

## Promo Codes

| Code | Discount |
|------|----------|
| EMBER10 | 10% off |
| FIRST20 | 20% off |
| STUDENT | 15% off |

## Design System

- **Display font:** Playfair Display (headings, card names)
- **Body font:** DM Sans (UI text, buttons)
- **Mono font:** DM Mono (prices, quantities)
- **Brand colour:** `#ff7a1a` — warm ember orange
- **Surface:** Near-black `#0f0f0f` with layered grays
- **Signature element:** Per-dish gradient backgrounds on card images, each unique to the cuisine
