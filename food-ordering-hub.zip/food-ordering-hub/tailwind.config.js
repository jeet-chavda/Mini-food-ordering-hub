/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['Playfair Display', 'Georgia', 'serif'],
        body: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['DM Mono', 'monospace'],
      },
      colors: {
        brand: {
          50:  '#fff8f0',
          100: '#ffe8cc',
          200: '#ffd199',
          300: '#ffb566',
          400: '#ff9c3d',
          500: '#ff7a1a',
          600: '#e05e00',
          700: '#b84d00',
          800: '#8c3b00',
          900: '#5c2700',
        },
        surface: {
          DEFAULT: '#0f0f0f',
          card:    '#1a1a1a',
          raised:  '#242424',
          border:  '#333333',
        },
        ink: {
          primary:   '#f5f0eb',
          secondary: '#a89f96',
          muted:     '#6b6360',
        },
      },
      boxShadow: {
        'card-hover': '0 20px 60px -10px rgba(255, 122, 26, 0.25)',
        'glow':       '0 0 40px rgba(255, 122, 26, 0.15)',
      },
    },
  },
  plugins: [],
}
