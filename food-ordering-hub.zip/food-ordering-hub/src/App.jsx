// src/App.jsx
import { useState } from 'react'
import { ShoppingBag, Sun, Moon, Flame } from 'lucide-react'
import MenuGrid from './components/MenuGrid'
import CartSidebar from './components/CartSidebar'
import { useCart } from './hooks/useCart'
import { useTheme } from './hooks/useTheme'
import { MENU_ITEMS } from './data/menuData'

export default function App() {
  const { theme, toggleTheme } = useTheme()
  const [cartOpen, setCartOpen] = useState(false)
  const {
    items,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    totalItems,
    totalPrice,
    itemCount,
  } = useCart()

  return (
    <div className="min-h-screen flex flex-col dark:bg-surface bg-gray-50 transition-colors duration-300">
      {/* Topbar */}
      <header className="sticky top-0 z-30 flex items-center justify-between px-6 py-3 bg-surface-card/80 dark:bg-surface-card/80 bg-white/80 backdrop-blur-md border-b border-surface-border dark:border-surface-border border-gray-100">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-brand-500 to-orange-600 flex items-center justify-center shadow-glow">
            <Flame size={16} className="text-white" />
          </div>
          <div>
            <span className="font-display font-semibold text-lg text-ink-primary dark:text-ink-primary text-gray-900 leading-none">
              Ember
            </span>
            <span className="block text-xs font-body text-ink-muted dark:text-ink-muted text-gray-400 leading-none -mt-0.5">
              Food Hub
            </span>
          </div>
        </div>

        {/* Right controls */}
        <div className="flex items-center gap-3">
          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-ink-secondary dark:text-ink-secondary text-gray-500 hover:text-brand-400 hover:bg-surface-raised dark:hover:bg-surface-raised hover:bg-gray-100 transition-colors"
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
          >
            {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
          </button>

          {/* Cart button (mobile / tablet) */}
          <button
            onClick={() => setCartOpen(true)}
            className="lg:hidden relative flex items-center gap-2 px-3 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-sm font-body font-medium transition-all active:scale-95"
            aria-label={`Open cart — ${totalItems} items`}
          >
            <ShoppingBag size={15} />
            {totalItems > 0 && (
              <span className="font-mono font-semibold">{totalItems}</span>
            )}
            {totalItems > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-white text-brand-500 text-xs font-mono font-bold flex items-center justify-center shadow">
                {totalItems}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Main layout */}
      <main className="flex flex-1 overflow-hidden">
        {/* Menu area */}
        <div className="flex-1 overflow-y-auto">
          {/* Hero strip */}
          <div className="px-6 pt-6 pb-2">
            <h1 className="font-display text-3xl font-bold text-ink-primary dark:text-ink-primary text-gray-900 mb-1">
              What are you <span className="italic text-brand-400">craving</span> today?
            </h1>
            <p className="text-sm font-body text-ink-secondary dark:text-ink-secondary text-gray-500">
              {MENU_ITEMS.length} dishes crafted with fire, served with care.
            </p>
          </div>

          <MenuGrid
            items={MENU_ITEMS}
            onAdd={addItem}
            onUpdateQuantity={updateQuantity}
            itemCount={itemCount}
          />
        </div>

        {/* Cart sidebar — always visible on large screens */}
        <CartSidebar
          items={items}
          onUpdateQuantity={updateQuantity}
          onRemove={removeItem}
          onClear={clearCart}
          totalPrice={totalPrice}
          totalItems={totalItems}
          isOpen={cartOpen}
          onClose={() => setCartOpen(false)}
        />
      </main>
    </div>
  )
}
