// src/components/FoodCard.jsx
import { useState } from 'react'
import { Plus, Minus, Star, Clock, Flame, Leaf, Zap } from 'lucide-react'

export default function FoodCard({ item, onAdd, onUpdateQuantity, quantity }) {
  const [isAdding, setIsAdding] = useState(false)
  const [ripple, setRipple] = useState(null)

  const handleAdd = (e) => {
    // Ripple effect
    const rect = e.currentTarget.getBoundingClientRect()
    setRipple({ x: e.clientX - rect.left, y: e.clientY - rect.top })
    setTimeout(() => setRipple(null), 600)

    setIsAdding(true)
    setTimeout(() => setIsAdding(false), 300)
    onAdd(item)
  }

  const inCart = quantity > 0

  return (
    <div
      className={`
        group relative flex flex-col rounded-2xl overflow-hidden
        bg-surface-card dark:bg-surface-card bg-white
        border border-surface-border dark:border-surface-border border-gray-100
        transition-all duration-300 ease-out cursor-default
        hover:-translate-y-1 hover:shadow-card-hover dark:hover:shadow-card-hover
        ${inCart ? 'ring-1 ring-brand-500 ring-opacity-60' : ''}
      `}
    >
      {/* Image area — gradient + emoji */}
      <div className={`relative h-44 bg-gradient-to-br ${item.gradient} overflow-hidden flex-shrink-0`}>
        {/* Ambient blur orb */}
        <div className="absolute inset-0 flex items-center justify-center">
          <span
            className="text-8xl select-none transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3"
            role="img"
            aria-label={item.name}
          >
            {item.emoji}
          </span>
        </div>

        {/* Top badges row */}
        <div className="absolute top-3 left-3 right-3 flex items-start justify-between">
          <div className="flex flex-col gap-1">
            {item.badge && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-body font-medium bg-brand-500 text-white shadow-lg">
                {item.badge}
              </span>
            )}
            {item.spicy && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-body bg-red-600/80 text-white backdrop-blur-sm">
                <Flame size={10} /> Spicy
              </span>
            )}
            {item.veg && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-body bg-green-600/80 text-white backdrop-blur-sm">
                <Leaf size={10} /> Veg
              </span>
            )}
          </div>

          {/* Rating pill */}
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-body font-semibold bg-black/40 text-white backdrop-blur-sm">
            <Star size={10} className="fill-amber-400 text-amber-400" />
            {item.rating}
          </span>
        </div>

        {/* In-cart quantity badge */}
        {inCart && (
          <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-brand-500 text-white text-xs font-body font-semibold px-2.5 py-1 rounded-full shadow-lg animate-[fadeIn_0.2s_ease]">
            <Zap size={10} />
            ×{quantity} in cart
          </div>
        )}

        {/* Bottom fade-to-card */}
        <div className="absolute bottom-0 inset-x-0 h-10 bg-gradient-to-t from-surface-card/70 dark:from-surface-card/70 from-white/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-4 gap-3">
        {/* Name + price */}
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-display font-semibold text-base leading-tight text-ink-primary dark:text-ink-primary text-gray-900 flex-1">
            {item.name}
          </h3>
          <span className="font-mono font-medium text-brand-400 text-sm flex-shrink-0 mt-0.5">
            ${item.price.toFixed(2)}
          </span>
        </div>

        {/* Description */}
        <p className="text-xs font-body leading-relaxed text-ink-secondary dark:text-ink-secondary text-gray-500 line-clamp-2 flex-1">
          {item.description}
        </p>

        {/* Meta row */}
        <div className="flex items-center gap-3 text-xs font-body text-ink-muted dark:text-ink-muted text-gray-400">
          <span className="flex items-center gap-1">
            <Clock size={11} />
            {item.prepTime}
          </span>
          <span className="w-1 h-1 rounded-full bg-current opacity-40" />
          <span>{item.calories} cal</span>
        </div>

        {/* Action area */}
        {inCart ? (
          <div className="flex items-center justify-between gap-2 mt-1">
            <div className="flex items-center gap-2 bg-surface-raised dark:bg-surface-raised bg-gray-100 rounded-xl p-1">
              <button
                onClick={() => onUpdateQuantity(item.id, -1)}
                className="w-7 h-7 rounded-lg flex items-center justify-center bg-surface-card dark:bg-surface-card bg-white text-ink-secondary dark:text-ink-secondary text-gray-500 hover:text-brand-400 transition-colors shadow-sm"
                aria-label="Decrease quantity"
              >
                <Minus size={13} />
              </button>
              <span className="font-mono font-semibold text-sm text-ink-primary dark:text-ink-primary text-gray-900 w-5 text-center">
                {quantity}
              </span>
              <button
                onClick={() => onUpdateQuantity(item.id, 1)}
                className="w-7 h-7 rounded-lg flex items-center justify-center bg-brand-500 text-white hover:bg-brand-600 transition-colors shadow-sm"
                aria-label="Increase quantity"
              >
                <Plus size={13} />
              </button>
            </div>
            <span className="font-mono text-sm font-semibold text-brand-400">
              ${(item.price * quantity).toFixed(2)}
            </span>
          </div>
        ) : (
          <button
            onClick={handleAdd}
            className="
              relative mt-1 w-full flex items-center justify-center gap-2
              py-2.5 rounded-xl overflow-hidden
              bg-brand-500 hover:bg-brand-600
              text-white text-sm font-body font-medium
              transition-all duration-200
              active:scale-95
              focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-400
            "
            aria-label={`Add ${item.name} to cart`}
          >
            {/* Ripple */}
            {ripple && (
              <span
                className="absolute rounded-full bg-white/30 animate-[ripple_0.6s_ease-out]"
                style={{
                  left: ripple.x - 50,
                  top: ripple.y - 50,
                  width: 100,
                  height: 100,
                  pointerEvents: 'none',
                }}
              />
            )}
            <Plus
              size={15}
              className={`transition-transform duration-200 ${isAdding ? 'rotate-90' : ''}`}
            />
            Add to Cart
          </button>
        )}
      </div>
    </div>
  )
}
