// src/components/CartSidebar.jsx
import { useState } from 'react'
import { X, Plus, Minus, Trash2, ShoppingBag, Tag, CheckCircle, ChevronRight } from 'lucide-react'

const PROMO_CODES = {
  EMBER10: 0.10,
  FIRST20: 0.20,
  STUDENT: 0.15,
}

export default function CartSidebar({ items, onUpdateQuantity, onRemove, onClear, totalPrice, totalItems, isOpen, onClose }) {
  const [promoInput, setPromoInput] = useState('')
  const [appliedPromo, setAppliedPromo] = useState(null)
  const [promoError, setPromoError] = useState('')
  const [checkoutStep, setCheckoutStep] = useState(null) // null | 'confirm' | 'success'

  const discount = appliedPromo ? totalPrice * PROMO_CODES[appliedPromo] : 0
  const deliveryFee = totalPrice > 0 ? (totalPrice > 50 ? 0 : 3.99) : 0
  const finalTotal = totalPrice - discount + deliveryFee

  const applyPromo = () => {
    const code = promoInput.trim().toUpperCase()
    if (PROMO_CODES[code]) {
      setAppliedPromo(code)
      setPromoError('')
    } else {
      setPromoError('Invalid promo code')
      setTimeout(() => setPromoError(''), 2000)
    }
    setPromoInput('')
  }

  const handleCheckout = () => {
    setCheckoutStep('confirm')
  }

  const confirmOrder = () => {
    setCheckoutStep('success')
    onClear()
    setTimeout(() => {
      setCheckoutStep(null)
      setAppliedPromo(null)
      onClose()
    }, 3000)
  }

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 right-0 h-full w-full sm:w-96
          flex flex-col z-50
          bg-surface-card dark:bg-surface-card bg-white
          border-l border-surface-border dark:border-surface-border border-gray-100
          shadow-2xl
          transition-transform duration-300 ease-out
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}
          lg:relative lg:translate-x-0 lg:w-96 lg:flex-shrink-0 lg:h-screen lg:sticky lg:top-0
        `}
        aria-label="Shopping cart"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-surface-border dark:border-surface-border border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <ShoppingBag size={18} className="text-brand-400" />
            <h2 className="font-display text-lg font-semibold text-ink-primary dark:text-ink-primary text-gray-900">
              Your Order
            </h2>
            {totalItems > 0 && (
              <span className="flex items-center justify-center w-5 h-5 rounded-full bg-brand-500 text-white text-xs font-mono font-semibold">
                {totalItems}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {items.length > 0 && (
              <button
                onClick={onClear}
                className="text-xs font-body text-ink-muted dark:text-ink-muted text-gray-400 hover:text-red-400 transition-colors px-2 py-1 rounded-lg hover:bg-red-50 dark:hover:bg-red-950"
                aria-label="Clear cart"
              >
                Clear all
              </button>
            )}
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 rounded-xl text-ink-muted dark:text-ink-muted text-gray-400 hover:text-ink-primary hover:bg-surface-raised dark:hover:bg-surface-raised hover:bg-gray-100 transition-colors"
              aria-label="Close cart"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Checkout Modal Overlay (confirm step) */}
        {checkoutStep === 'confirm' && (
          <div className="absolute inset-0 z-10 flex flex-col bg-surface-card dark:bg-surface-card bg-white">
            <div className="flex items-center gap-2 px-5 py-4 border-b border-surface-border dark:border-surface-border border-gray-100">
              <button
                onClick={() => setCheckoutStep(null)}
                className="p-1 text-ink-muted dark:text-ink-muted text-gray-400 hover:text-ink-primary transition-colors"
              >
                <X size={18} />
              </button>
              <h2 className="font-display text-lg font-semibold text-ink-primary dark:text-ink-primary text-gray-900">
                Confirm Order
              </h2>
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
              {items.map((item) => (
                <div key={item.id} className="flex items-center justify-between text-sm font-body">
                  <span className="text-ink-secondary dark:text-ink-secondary text-gray-600">
                    {item.name} <span className="text-brand-400">×{item.quantity}</span>
                  </span>
                  <span className="font-mono text-ink-primary dark:text-ink-primary text-gray-900">
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              ))}
              <div className="pt-3 border-t border-surface-border dark:border-surface-border border-gray-100 space-y-1.5 text-sm font-body">
                <div className="flex justify-between text-ink-secondary dark:text-ink-secondary text-gray-500">
                  <span>Subtotal</span>
                  <span className="font-mono">${totalPrice.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-400">
                    <span>Promo ({appliedPromo})</span>
                    <span className="font-mono">-${discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-ink-secondary dark:text-ink-secondary text-gray-500">
                  <span>Delivery</span>
                  <span className="font-mono">{deliveryFee === 0 ? 'FREE' : `$${deliveryFee.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between font-semibold text-base pt-1 text-ink-primary dark:text-ink-primary text-gray-900">
                  <span>Total</span>
                  <span className="font-mono text-brand-400">${finalTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>
            <div className="p-5 border-t border-surface-border dark:border-surface-border border-gray-100">
              <button
                onClick={confirmOrder}
                className="w-full py-3.5 rounded-2xl bg-brand-500 hover:bg-brand-600 text-white font-body font-semibold text-sm transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                Place Order <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* Success overlay */}
        {checkoutStep === 'success' && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-surface-card dark:bg-surface-card bg-white px-6 text-center">
            <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center mb-5 animate-[bounceIn_0.5s_ease]">
              <CheckCircle size={40} className="text-green-400" />
            </div>
            <h2 className="font-display text-2xl font-bold text-ink-primary dark:text-ink-primary text-gray-900 mb-2">
              Order Placed!
            </h2>
            <p className="text-sm font-body text-ink-secondary dark:text-ink-secondary text-gray-500">
              Your food is being prepared. Estimated time: 25–30 min.
            </p>
          </div>
        )}

        {/* Empty state */}
        {items.length === 0 && !checkoutStep && (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
            <span className="text-6xl mb-4 select-none opacity-40">🛒</span>
            <p className="font-display text-base text-ink-primary dark:text-ink-primary text-gray-900 mb-1">
              Your cart is empty
            </p>
            <p className="text-xs font-body text-ink-muted dark:text-ink-muted text-gray-400">
              Add some dishes from the menu to get started.
            </p>
          </div>
        )}

        {/* Cart items */}
        {items.length > 0 && !checkoutStep && (
          <>
            <div className="flex-1 overflow-y-auto px-5 py-3 space-y-3">
              {items.map((item) => (
                <CartItem
                  key={item.id}
                  item={item}
                  onUpdate={onUpdateQuantity}
                  onRemove={onRemove}
                />
              ))}

              {/* Free delivery nudge */}
              {totalPrice > 0 && totalPrice < 50 && (
                <div className="mt-2 p-3 rounded-xl bg-amber-500/10 dark:bg-amber-500/10 bg-amber-50 border border-amber-500/20">
                  <p className="text-xs font-body text-amber-500 dark:text-amber-400">
                    Add <span className="font-semibold">${(50 - totalPrice).toFixed(2)}</span> more for free delivery 🎉
                  </p>
                  <div className="mt-2 h-1.5 rounded-full bg-amber-200/50 overflow-hidden">
                    <div
                      className="h-full bg-amber-400 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min((totalPrice / 50) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              )}
              {totalPrice >= 50 && (
                <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/20">
                  <p className="text-xs font-body text-green-400 font-medium">✓ Free delivery unlocked!</p>
                </div>
              )}
            </div>

            {/* Promo code */}
            <div className="px-5 py-3 border-t border-surface-border dark:border-surface-border border-gray-100">
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Tag size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-muted dark:text-ink-muted text-gray-400" />
                  <input
                    type="text"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && applyPromo()}
                    placeholder="Promo code"
                    className="
                      w-full pl-8 pr-3 py-2 rounded-xl text-sm font-body
                      bg-surface-raised dark:bg-surface-raised bg-gray-100
                      text-ink-primary dark:text-ink-primary text-gray-900
                      placeholder:text-ink-muted dark:placeholder:text-ink-muted placeholder:text-gray-400
                      border border-transparent focus:outline-none focus:border-brand-500
                      transition
                    "
                    aria-label="Enter promo code"
                    disabled={!!appliedPromo}
                  />
                </div>
                <button
                  onClick={applyPromo}
                  disabled={!!appliedPromo || !promoInput.trim()}
                  className="px-3 py-2 rounded-xl text-sm font-body font-medium bg-brand-500 text-white hover:bg-brand-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
                >
                  Apply
                </button>
              </div>
              {promoError && (
                <p className="text-xs text-red-400 font-body mt-1.5">{promoError}</p>
              )}
              {appliedPromo && (
                <div className="flex items-center justify-between mt-1.5">
                  <p className="text-xs text-green-400 font-body">
                    ✓ {appliedPromo} — {(PROMO_CODES[appliedPromo] * 100).toFixed(0)}% off applied!
                  </p>
                  <button
                    onClick={() => setAppliedPromo(null)}
                    className="text-xs text-ink-muted dark:text-ink-muted text-gray-400 hover:text-red-400 transition-colors"
                  >
                    Remove
                  </button>
                </div>
              )}
            </div>

            {/* Order summary */}
            <div className="px-5 py-3 border-t border-surface-border dark:border-surface-border border-gray-100 space-y-1.5">
              <div className="flex justify-between text-sm font-body text-ink-secondary dark:text-ink-secondary text-gray-500">
                <span>Subtotal</span>
                <span className="font-mono">${totalPrice.toFixed(2)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm font-body text-green-400">
                  <span>Discount</span>
                  <span className="font-mono">-${discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-body text-ink-secondary dark:text-ink-secondary text-gray-500">
                <span>Delivery</span>
                <span className="font-mono">{deliveryFee === 0 ? 'FREE' : `$${deliveryFee.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-base font-semibold font-body text-ink-primary dark:text-ink-primary text-gray-900 pt-1">
                <span>Total</span>
                <span className="font-mono text-brand-400">${finalTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Checkout button */}
            <div className="p-5 border-t border-surface-border dark:border-surface-border border-gray-100">
              <button
                onClick={handleCheckout}
                className="
                  w-full py-3.5 rounded-2xl
                  bg-brand-500 hover:bg-brand-600
                  text-white font-body font-semibold text-sm
                  transition-all duration-200 active:scale-95
                  flex items-center justify-center gap-2
                  shadow-glow
                "
              >
                Checkout — ${finalTotal.toFixed(2)}
                <ChevronRight size={16} />
              </button>
              <p className="text-center text-xs font-body text-ink-muted dark:text-ink-muted text-gray-400 mt-2">
                Try: EMBER10 · FIRST20 · STUDENT
              </p>
            </div>
          </>
        )}
      </aside>
    </>
  )
}

function CartItem({ item, onUpdate, onRemove }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-xl bg-surface-raised dark:bg-surface-raised bg-gray-50 group">
      {/* Emoji thumb */}
      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center flex-shrink-0 text-xl select-none`}>
        {item.emoji}
      </div>

      {/* Details */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-body font-medium text-ink-primary dark:text-ink-primary text-gray-900 truncate">
          {item.name}
        </p>
        <p className="text-xs font-mono text-brand-400">${item.price.toFixed(2)} each</p>
      </div>

      {/* Qty controls */}
      <div className="flex items-center gap-1.5">
        <button
          onClick={() => onUpdate(item.id, -1)}
          className="w-6 h-6 rounded-lg flex items-center justify-center bg-surface-border dark:bg-surface-border bg-gray-200 text-ink-secondary dark:text-ink-secondary text-gray-500 hover:text-brand-400 transition-colors text-xs"
          aria-label="Decrease"
        >
          <Minus size={11} />
        </button>
        <span className="w-5 text-center font-mono text-sm font-semibold text-ink-primary dark:text-ink-primary text-gray-900">
          {item.quantity}
        </span>
        <button
          onClick={() => onUpdate(item.id, 1)}
          className="w-6 h-6 rounded-lg flex items-center justify-center bg-brand-500 text-white hover:bg-brand-600 transition-colors"
          aria-label="Increase"
        >
          <Plus size={11} />
        </button>
      </div>

      {/* Subtotal + remove */}
      <div className="flex flex-col items-end gap-0.5">
        <span className="font-mono text-sm font-semibold text-ink-primary dark:text-ink-primary text-gray-900">
          ${(item.price * item.quantity).toFixed(2)}
        </span>
        <button
          onClick={() => onRemove(item.id)}
          className="text-ink-muted dark:text-ink-muted text-gray-300 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
          aria-label={`Remove ${item.name}`}
        >
          <Trash2 size={12} />
        </button>
      </div>
    </div>
  )
}
