// src/components/MenuGrid.jsx
import { useState, useMemo } from 'react'
import { Search, X, SlidersHorizontal } from 'lucide-react'
import FoodCard from './FoodCard'
import { CATEGORIES } from '../data/menuData'

export default function MenuGrid({ items, onAdd, onUpdateQuantity, itemCount }) {
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('all')
  const [sortBy, setSortBy] = useState('default')

  const filtered = useMemo(() => {
    let result = items

    // Category filter
    if (activeCategory !== 'all') {
      result = result.filter((i) => i.category === activeCategory)
    }

    // Search filter
    if (search.trim()) {
      const q = search.toLowerCase()
      result = result.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          i.description.toLowerCase().includes(q) ||
          i.category.toLowerCase().includes(q)
      )
    }

    // Sort
    if (sortBy === 'price-asc') result = [...result].sort((a, b) => a.price - b.price)
    if (sortBy === 'price-desc') result = [...result].sort((a, b) => b.price - a.price)
    if (sortBy === 'rating') result = [...result].sort((a, b) => b.rating - a.rating)

    return result
  }, [items, search, activeCategory, sortBy])

  const clearSearch = () => setSearch('')

  return (
    <section className="flex-1 overflow-y-auto px-6 py-6" aria-label="Menu">
      {/* Search + Sort toolbar */}
      <div className="flex items-center gap-3 mb-5">
        <div className="relative flex-1">
          <Search
            size={15}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-muted dark:text-ink-muted text-gray-400 pointer-events-none"
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search dishes, ingredients…"
            className="
              w-full pl-9 pr-9 py-2.5
              rounded-xl text-sm font-body
              bg-surface-raised dark:bg-surface-raised bg-gray-100
              text-ink-primary dark:text-ink-primary text-gray-900
              placeholder:text-ink-muted dark:placeholder:text-ink-muted placeholder:text-gray-400
              border border-transparent
              focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500
              transition
            "
            aria-label="Search menu"
          />
          {search && (
            <button
              onClick={clearSearch}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-muted dark:text-ink-muted text-gray-400 hover:text-brand-400 transition-colors"
              aria-label="Clear search"
            >
              <X size={14} />
            </button>
          )}
        </div>

        {/* Sort select */}
        <div className="relative">
          <SlidersHorizontal
            size={13}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-muted dark:text-ink-muted text-gray-400 pointer-events-none"
          />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="
              pl-8 pr-3 py-2.5 rounded-xl text-sm font-body appearance-none
              bg-surface-raised dark:bg-surface-raised bg-gray-100
              text-ink-primary dark:text-ink-primary text-gray-900
              border border-transparent focus:outline-none focus:border-brand-500
              transition cursor-pointer
            "
            aria-label="Sort by"
          >
            <option value="default">Default</option>
            <option value="rating">Top Rated</option>
            <option value="price-asc">Price ↑</option>
            <option value="price-desc">Price ↓</option>
          </select>
        </div>
      </div>

      {/* Category pills */}
      <div
        className="flex items-center gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide"
        role="tablist"
        aria-label="Filter by category"
      >
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            role="tab"
            aria-selected={activeCategory === cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`
              flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-body font-medium
              transition-all duration-200
              focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-400
              ${
                activeCategory === cat.id
                  ? 'bg-brand-500 text-white shadow-glow'
                  : 'bg-surface-raised dark:bg-surface-raised bg-gray-100 text-ink-secondary dark:text-ink-secondary text-gray-500 hover:text-brand-400'
              }
            `}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Results count */}
      <p className="text-xs font-body text-ink-muted dark:text-ink-muted text-gray-400 mb-4">
        {filtered.length === 0
          ? 'No dishes match your search.'
          : `${filtered.length} dish${filtered.length !== 1 ? 'es' : ''}`}
      </p>

      {/* Grid */}
      {filtered.length > 0 ? (
        <div
          className="grid gap-5"
          style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))' }}
        >
          {filtered.map((item) => (
            <FoodCard
              key={item.id}
              item={item}
              onAdd={onAdd}
              onUpdateQuantity={onUpdateQuantity}
              quantity={itemCount(item.id)}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <span className="text-6xl mb-4 select-none">🍽️</span>
          <p className="font-display text-lg text-ink-primary dark:text-ink-primary text-gray-900 mb-1">
            Nothing here yet
          </p>
          <p className="text-sm font-body text-ink-muted dark:text-ink-muted text-gray-400">
            Try a different category or clear your search.
          </p>
          {search && (
            <button
              onClick={clearSearch}
              className="mt-4 px-4 py-2 rounded-xl bg-brand-500 text-white text-sm font-body hover:bg-brand-600 transition"
            >
              Clear search
            </button>
          )}
        </div>
      )}
    </section>
  )
}
